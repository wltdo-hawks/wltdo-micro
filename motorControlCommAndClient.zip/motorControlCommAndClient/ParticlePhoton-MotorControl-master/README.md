# README #

This application provides motor control capabilities through a Web interface/Application.

## Hardware
1. Particle Photon x 1
2. DC motor/DC Pump x 1
3. TIP31C Transistor x 1
4. 350 Ohm Resistor x 1
5. 5V Supply from a Battery

**I'll update more information about the project in time**
